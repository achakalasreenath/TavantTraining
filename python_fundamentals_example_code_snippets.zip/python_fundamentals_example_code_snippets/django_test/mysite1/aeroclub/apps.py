from django.apps import AppConfig


class AeroclubConfig(AppConfig):
    name = 'aeroclub'
